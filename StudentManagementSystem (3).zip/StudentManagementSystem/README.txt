# Student Management System — Mini Project

## Requirements
- A computer with a modern web browser (Chrome, Edge, Firefox, etc.).
- A text editor such as Visual Studio Code or Notepad.
- No installation, server, or backend is required.

## How to run
1. Extract `StudentManagementSystem.zip`.
2. Open the `StudentManagementSystem` folder.
3. Double-click `index.html`, or right-click it and choose your browser.
4. Use **Add Student** to add a record. Search, filter, edit, and delete records using the table.

## Files
- `index.html` — page structure and form
- `style.css` — layout, colors, responsive design
- `script.js` — CRUD actions, validation, dashboard statistics, and browser local storage

## Features
- Add, view, search, filter, edit, and delete student records
- Unique student ID validation
- Email and marks validation
- Dashboard counts and average marks
- Saves records in browser local storage
- Responsive layout for mobile and desktop

## Important limitation
This is a frontend-only mini project. Records are saved only in the current browser's local storage on this device. They are not shared between computers or browser profiles, and clearing browser storage can remove them. It does not include secure user accounts or a central database.

## Suggested project abstract
The Student Management System is a web-based frontend application designed to organize basic student information. It allows users to add, view, search, update, and delete student records, including student ID, name, department, email, and marks. The dashboard summarizes the number of students, departments, and average marks. HTML is used to structure the application, CSS is used for styling and responsive layout, and JavaScript handles validation and record operations. Browser local storage retains data between visits without requiring a backend server.

## Suggested future enhancements
- Connect a database and backend
- Add administrator login
- Record attendance and grades by subject
- Export student lists to CSV or PDF
