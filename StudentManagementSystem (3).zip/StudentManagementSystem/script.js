const STORAGE_KEY = "studentDeskRecords";
const starterStudents = [
  { id: "STU101", name: "Aarav Sharma", department: "Computer Science", email: "aarav@example.com", marks: 88 },
  { id: "STU102", name: "Diya Patel", department: "Information Technology", email: "diya@example.com", marks: 92 },
  { id: "STU103", name: "Rohan Kumar", department: "Mathematics", email: "rohan@example.com", marks: 76 }
];

const $ = (id) => document.getElementById(id);
const modal = $("studentModal");
const form = $("studentForm");
let students = loadStudents();

function loadStudents() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved === null ? [...starterStudents] : JSON.parse(saved);
  } catch (error) {
    console.error("Could not read student records:", error);
    return [...starterStudents];
  }
}

function saveStudents() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
  } catch (error) {
    showToast("Could not save records in this browser.");
  }
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function renderStudents() {
  const search = $("searchInput").value.trim().toLowerCase();
  const department = $("departmentFilter").value;
  const filtered = students.map((student, index) => ({ student, index })).filter(({student}) => {
    const matchesSearch = [student.id, student.name, student.department, student.email]
      .some(value => String(value).toLowerCase().includes(search));
    return matchesSearch && (!department || student.department === department);
  });

  $("studentTableBody").innerHTML = filtered.map(({student, index}) => `
    <tr>
      <td><div class="student-cell"><div class="avatar">${escapeHTML(initials(student.name))}</div>
        <div><div class="student-name">${escapeHTML(student.name)}</div><div class="student-email-small">${escapeHTML(student.email)}</div></div>
      </div></td>
      <td><span class="id-pill">${escapeHTML(student.id)}</span></td>
      <td><span class="department-pill">${escapeHTML(student.department)}</span></td>
      <td>${escapeHTML(student.email)}</td>
      <td><span class="mark-value">${Number(student.marks).toLocaleString(undefined, {maximumFractionDigits: 1})}%</span></td>
      <td><div class="action-group">
        <button class="icon-btn" title="Edit ${escapeHTML(student.name)}" aria-label="Edit ${escapeHTML(student.name)}" data-action="edit" data-index="${index}">✎</button>
        <button class="icon-btn delete-btn" title="Delete ${escapeHTML(student.name)}" aria-label="Delete ${escapeHTML(student.name)}" data-action="delete" data-index="${index}">⌫</button>
      </div></td>
    </tr>`).join("");

  $("emptyState").classList.toggle("visible", filtered.length === 0);
  $("recordCount").textContent = `${filtered.length} ${filtered.length === 1 ? "record" : "records"}`;
  $("totalStudents").textContent = students.length;
  $("totalDepartments").textContent = new Set(students.map(student => student.department)).size;
  const average = students.length ? students.reduce((sum, student) => sum + Number(student.marks), 0) / students.length : 0;
  $("averageMarks").textContent = `${average.toFixed(1)}%`;
}

function openModal(index = null) {
  form.reset();
  $("formMessage").textContent = "";
  $("editIndex").value = index === null ? "" : String(index);
  $("modalTitle").textContent = index === null ? "Add Student" : "Edit Student";
  $("saveStudentBtn").textContent = index === null ? "Save Student" : "Update Student";

  if (index !== null) {
    const student = students[index];
    $("studentId").value = student.id;
    $("studentName").value = student.name;
    $("studentDepartment").value = student.department;
    $("studentEmail").value = student.email;
    $("studentMarks").value = student.marks;
  }
  modal.hidden = false;
  $("studentId").focus();
}

function closeModal() {
  modal.hidden = true;
  form.reset();
  $("formMessage").textContent = "";
}

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timeout);
  showToast.timeout = setTimeout(() => toast.classList.remove("show"), 2600);
}

function saveStudent(event) {
  event.preventDefault();
  const editIndex = $("editIndex").value;
  const student = {
    id: $("studentId").value.trim(),
    name: $("studentName").value.trim(),
    department: $("studentDepartment").value,
    email: $("studentEmail").value.trim(),
    marks: Number($("studentMarks").value)
  };

  if (!student.id || !student.name || !student.department || !student.email) {
    $("formMessage").textContent = "Please complete all required fields.";
    return;
  }
  if (!Number.isFinite(student.marks) || student.marks < 0 || student.marks > 100) {
    $("formMessage").textContent = "Marks must be between 0 and 100.";
    return;
  }
  const duplicate = students.some((existing, index) =>
    existing.id.toLowerCase() === student.id.toLowerCase() && String(index) !== editIndex
  );
  if (duplicate) {
    $("formMessage").textContent = "This student ID already exists. Please use a unique ID.";
    return;
  }

  if (editIndex === "") {
    students.push(student);
    showToast("Student added successfully.");
  } else {
    students[Number(editIndex)] = student;
    showToast("Student details updated.");
  }
  saveStudents();
  renderStudents();
  closeModal();
}

$("addStudentTop").addEventListener("click", () => openModal());
$("emptyAddBtn").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);
form.addEventListener("submit", saveStudent);
$("searchInput").addEventListener("input", renderStudents);
$("departmentFilter").addEventListener("change", renderStudents);

$("studentTableBody").addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const index = Number(button.dataset.index);

  if (button.dataset.action === "edit") {
    openModal(index);
  } else if (button.dataset.action === "delete") {
    const student = students[index];
    if (confirm(`Delete the record for ${student.name} (${student.id})?`)) {
      students.splice(index, 1);
      saveStudents();
      renderStudents();
      showToast("Student record deleted.");
    }
  }
});

modal.addEventListener("click", event => {
  if (event.target === modal) closeModal();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape" && !modal.hidden) closeModal();
});

renderStudents();
